#pragma once

struct Point3D
{
	float x;
	float y;
	float z;

	Point3D()
	{
		x = 0.0;
		y = 0.0;
		z = 0.0;
	}
};

