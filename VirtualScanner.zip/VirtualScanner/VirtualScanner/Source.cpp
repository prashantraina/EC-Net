#include <vl\generic.h>
#include <vl\pgm.h>
#include <vl\imopv.h>
#include "vl\slic.h"
#include "vl\mathop.h"
#include <iostream>
#include <fstream>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <set>
#include <list>
#include <time.h>
#include <string>
using namespace std;

#include <windows.h>

#include "Dependencies\glew\glew.h"
#include "Dependencies\freeglut\freeglut.h"
#include "Dependencies\glm\glm.hpp"
#include "Dependencies\glm\gtc\matrix_transform.hpp"
#include "BasicDataType.h"

// Type of function pointer for my internal malloc
typedef void *(*TypeUTLMallocFuncPtr)(size_t);
typedef void(*TypeUTLFreeFuncPtr)(void *);


// Global variable in this utility.c for allocating
TypeUTLMallocFuncPtr ptrUTLMalloc = &malloc;
TypeUTLFreeFuncPtr   ptrUTLFree = &free;


/***********************************************************************/
/************************* Global Definitions **************************/
/***********************************************************************/

#define _FOVY                50.0
#define _ASPECT               1.0
#define _ZNEAR                2.0
#define _ZFAR                 4.0
#define PI                   3.1415926536

bool loadOBJ(
	const char * path,
	std::vector<glm::vec3> & out_vertices,
	std::vector<glm::vec2> & out_uvs,
	std::vector<glm::vec3> & out_normals
) {
	printf("Loading OBJ file %s...\n", path);

	std::vector<unsigned int> vertexIndices, uvIndices, normalIndices;
	std::vector<glm::vec3> temp_vertices;
	std::vector<glm::vec2> temp_uvs;
	std::vector<glm::vec3> temp_normals;

	out_vertices.clear();
	out_uvs.clear();
	out_normals.clear();

	FILE * file = fopen(path, "r");
	if (file == NULL) {
		printf("Impossible to open the file !\n");
		getchar();
		return false;
	}

	//glm::vec3 maxPosition(-INFINITE, -INFINITE, -INFINITE);
	//glm::vec3 minPosition(INFINITE,INFINITE,INFINITE);
	while (1) {

		char lineHeader[128];
		int res = fscanf(file, "%s", lineHeader);
		if (res == EOF)
			break; // EOF = End Of File. Quit the loop.

				   // else : parse lineHeader

		if (strcmp(lineHeader, "v") == 0) {
			glm::vec3 vertex;
			fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z);

			//if (vertex.x < minPosition.x)  minPosition.x = vertex.x;
			//if (vertex.y < minPosition.y)  minPosition.y = vertex.y;
			//if (vertex.z < minPosition.z)  minPosition.z = vertex.z;

			temp_vertices.push_back(vertex);
		}
		else if (strcmp(lineHeader, "vt") == 0) {
			glm::vec2 uv;
			fscanf(file, "%f %f\n", &uv.x, &uv.y);
			uv.y = -uv.y;
			temp_uvs.push_back(uv);
		}
		else if (strcmp(lineHeader, "vn") == 0) {
			glm::vec3 normal;
			fscanf(file, "%f %f %f\n", &normal.x, &normal.y, &normal.z);
			temp_normals.push_back(normal);
		}
		else if (strcmp(lineHeader, "f") == 0) {
			std::string vertex1, vertex2, vertex3;
			unsigned int vertexIndex[3], uvIndex[3], normalIndex[3];
			if (temp_uvs.size() != 0)
			{
				fscanf(file, "%d/%d/%d %d/%d/%d %d/%d/%d\n",
					&vertexIndex[0], &uvIndex[0], &normalIndex[0],
					&vertexIndex[1], &uvIndex[1], &normalIndex[1],
					&vertexIndex[2], &uvIndex[2], &normalIndex[2]);
				vertexIndices.push_back(vertexIndex[0]);
				vertexIndices.push_back(vertexIndex[1]);
				vertexIndices.push_back(vertexIndex[2]);
				uvIndices.push_back(uvIndex[0]);
				uvIndices.push_back(uvIndex[1]);
				uvIndices.push_back(uvIndex[2]);
				normalIndices.push_back(normalIndex[0]);
				normalIndices.push_back(normalIndex[1]);
				normalIndices.push_back(normalIndex[2]);
			}
			else
			{
				fscanf(file, "%d//%d %d//%d %d//%d\n",
					&vertexIndex[0], &normalIndex[0],
					&vertexIndex[1], &normalIndex[1],
					&vertexIndex[2], &normalIndex[2]);
				vertexIndices.push_back(vertexIndex[0]);
				vertexIndices.push_back(vertexIndex[1]);
				vertexIndices.push_back(vertexIndex[2]);
				normalIndices.push_back(normalIndex[0]);
				normalIndices.push_back(normalIndex[1]);
				normalIndices.push_back(normalIndex[2]);
			}

		}
		else {
			char stupidBuffer[1000];
			fgets(stupidBuffer, 1000, file);
		}

	}

	// For each vertex of each triangle
	for (unsigned int i = 0; i<vertexIndices.size(); i++) {

		// Get the indices of its attributes
		unsigned int vertexIndex = vertexIndices[i];
		unsigned int normalIndex = normalIndices[i];

		// Get the attributes thanks to the index
		glm::vec3 vertex = temp_vertices[vertexIndex - 1];
		glm::vec3 normal = temp_normals[normalIndex - 1];

		// Put the attributes in buffers
		out_vertices.push_back(vertex);
		out_normals.push_back(normal);

		if (uvIndices.size() != 0)
		{
			unsigned int uvIndex = uvIndices[i];
			glm::vec2 uv = temp_uvs[uvIndex - 1];
			out_uvs.push_back(uv);
		}
	}

	return true;
}

bool loadOFF(
	const char * path,
	std::vector<glm::vec3> & out_vertices
)
{
	std::vector<unsigned int> vertexIndices;
	std::vector<glm::vec3> temp_vertices;

	out_vertices.clear();
	FILE * file = fopen(path, "r");
	if (file == NULL) {
		printf("Impossible to open the file !\n");
		getchar();
		return false;
	}

	char lineHeader[128];
	int res = fscanf(file, "%s", lineHeader);

	int vertexNum = 0;
	int faceNum = 0;
	int edgeNum = 0;
	fscanf(file, "%d %d %d\n", &vertexNum, &faceNum, &edgeNum);

	for (int i = 0; i < vertexNum; i++)
	{
		glm::vec3 vertex;
		fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z);
		temp_vertices.push_back(vertex);
	}

	for (int i = 0; i < faceNum; i++)
	{
		unsigned int vertexIndex[3];
		int faceType;
		fscanf(file, "%d %d %d %d\n", &faceType, &vertexIndex[0], &vertexIndex[1], &vertexIndex[2]);
		vertexIndices.push_back(vertexIndex[0]);
		vertexIndices.push_back(vertexIndex[1]);
		vertexIndices.push_back(vertexIndex[2]);
	}

	// For each vertex of each triangle
	for (unsigned int i = 0; i<vertexIndices.size(); i++)
	{
		// Get the indices of its attributes
		unsigned int vertexIndex = vertexIndices[i];

		// Get the attributes thanks to the index
		glm::vec3 vertex = temp_vertices[vertexIndex];

		// Put the attributes in buffers
		out_vertices.push_back(vertex);
	}

	return true;
}

vector<string> split(const string &s, const string &seperator) {
	vector<string> result;
	typedef string::size_type string_size;
	string_size i = 0;

	while (i != s.size()) {

		int flag = 0;
		while (i != s.size() && flag == 0) {
			flag = 1;
			for (string_size x = 0; x < seperator.size(); ++x)
				if (s[i] == seperator[x]) {
					++i;
					flag = 0;
					break;
				}
		}


		flag = 0;
		string_size j = i;
		while (j != s.size() && flag == 0) {
			for (string_size x = 0; x < seperator.size(); ++x)
				if (s[j] == seperator[x]) {
					flag = 1;
					break;
				}
			if (flag == 0)
				++j;
		}
		if (i != j) {
			result.push_back(s.substr(i, j - i));
			i = j;
		}
	}
	return result;
}

//////////////////OpenGL related functions//////////////
void
close_GL_RC(HGLRC hRC)
{
	// Make the rendering context not current 
	wglMakeCurrent(NULL, NULL);

	// Delete the rendering context 
	wglDeleteContext(hRC);
}

HGLRC
open_GL_RC(int window_width, int window_height)
{
	//////////////////////////////////////////////
	// Define BIH (Bitmap Information Header)
	// - setup dimensions and color format of a device-independent bitmap (DIB)
	//
	// Check MSDN:
	// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/gdi/bitmaps_1rw2.asp

	BITMAPINFOHEADER BIH;


	// Specifies the number of bytes required by the structure
	BIH.biSize = sizeof(BITMAPINFOHEADER);

	// Specifies the width and height of the bitmap (your virtual window)
	BIH.biWidth = window_width;
	BIH.biHeight = window_height;

	// Specifies the number of planes for the target device
	BIH.biPlanes = 1;

	// Specifies the number of bits per pixel
	//BIH.biBitCount = 32 ;                             // default: 16 bit color

	// Specifies the type of compression 
	BIH.biCompression = BI_RGB;                        // this is Uncompressed RGB

													   // Specifies the size, in bytes, of the image.
													   // This may be set to zero for BI_RGB bitmaps.
	BIH.biSizeImage = 0;


	//////////////////////////////////////////////
	// Make a new DC and DIbitmap for OpenGL to draw onto
	// 
	// DC: device context

	HDC     hDC2;
	HBITMAP hBMP, hBMP_old;

	static PIXELFORMATDESCRIPTOR pfd2;

	void * m_pBits;

	GLuint PixelFormat;

	DWORD code;

	int ret;


	// Create a memory device context
	hDC2 = CreateCompatibleDC(NULL);

	// Obtain the pixel format (-> pfd2) of your display
	DescribePixelFormat(hDC2, 1, sizeof(PIXELFORMATDESCRIPTOR), &pfd2);

	// Get the current color bit depth of your display
	BIH.biBitCount = pfd2.cColorBits;

	// Creates a DIB that the application can write to directly
	hBMP = CreateDIBSection(hDC2,                     // handle to DC
		(BITMAPINFO *)& BIH,   // bitmap information header of the DIB
		DIB_RGB_COLORS,           // data type indicator ( DIB_PAL_COLORS or DIB_RGB_COLORS )
		&m_pBits,                // (out) Pointer to a variable that receives a pointer
								 //       to the location of the DIB bit values
		NULL,
		0);

	// selects an object into the specified device context (DC).
	hBMP_old = (HBITMAP)SelectObject(hDC2, hBMP);


	//////////////////////////////////////////////
	// Create PFD (Pixel Format Descriptor) for the hidden window
	// - pfd tells windows how we want the window to be

	static PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof(PIXELFORMATDESCRIPTOR) ,                // Size Of This Pixel Format Descriptor
		1 ,                                               // Version Number

		PFD_DRAW_TO_BITMAP |                              // Format Must Support Bitmap Rendering
		PFD_SUPPORT_OPENGL |                              // Format Must Support OpenGL
		PFD_SUPPORT_GDI ,                                 // Format Must Support OpenGL,

		0  ,                                              // PFD_TYPE_RGBA , Request An RGBA Format
		16 ,                                              // Select Our Color Depth

		0, 0, 0, 0, 0, 0,                                 // Color Bits Ignored
		0, //1,                                           // No Alpha Buffer
		0,                                                // Shift Bit Ignored
		0,                                                // No Accumulation Buffer
		0, 0, 0, 0,                                       // Accumulation Bits Ignored
		0, //16,                                          // 16 Bit Z-Buffer (Depth Buffer)  
		0,                                                // No Stencil Buffer
		0,                                                // No Auxiliary Buffer
		0, //PFD_MAIN_PLANE,                              // Main Drawing Layer
		0,                                                // Reserved
		0, 0, 0                                           // Layer Masks Ignored
	};

	pfd.cColorBits = pfd2.cColorBits;                // same color depth as the current display

	code = GetLastError();

	// If the function succeeds, the return value is a pixel format index (one-based) that is
	// the closest match to the given pixel format descriptor.
	PixelFormat = ChoosePixelFormat(hDC2, &pfd);    // note: *pretend* we want a new pixel format

													// sets the pixel format of the specified device context to the format
	ret = SetPixelFormat(hDC2, PixelFormat, &pfd);
	code = GetLastError();


	//////////////////////////////////////////////
	// Create the rendering context and enable it by makeCurrent!
	// Note: this is the same as glXMakeCurrent in GLX

	HGLRC hRC;

	hRC = wglCreateContext(hDC2);
	ret = wglMakeCurrent(hDC2, hRC);


	return hRC;
}

void
initView()
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//glRotatef(10.f, 1, 0, 0);
	//glTranslatef   ( 0.0f , 0.0f , -3.0f ) ;        // move the object -3.0 along eye-Z away from eye
}

void
initProj(float rotAngle, int i)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	float label = 0;
	if (i % 3 == 0) { label = 1; }
	else if (i%3==1) { label = -1; }
	float angle = 60.0*label;

	glm::vec4 ori = glm::vec4(0.f, 0.f, 3.f, 1.f);
	ori = glm::rotate(glm::mat4(), rotAngle, glm::vec3(0, 1, 0)) * ori;
	ori = glm::rotate(glm::mat4(), (float)(angle/180.0*PI), glm::vec3(1,0,0))*ori;
	
	//ori = glm::rotate(glm::mat4(), 15.f*label, glm::vec3(1, 0, 0)) * ori;
	//ori = glm::translate(glm::mat4(), glm::vec3(0, 0, -3))*ori;	
	gluPerspective(_FOVY, _ASPECT, _ZNEAR, _ZFAR);
	gluLookAt(ori.x, ori.y, ori.z, 0.f, 0.f, 0.f, 0.f, 1.f, 0.f);
	glMatrixMode(GL_MODELVIEW);
}

void
myGLInit()
{
	// Clear color for glClear
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Anti-aliasing
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);

	// Setup modelview and projection
	initView();
	//initProj();
}

void
display(const char* path)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	/////import model////////
	string modelType = "off";
	bool state;
	std::vector<glm::vec3> vertices;
	if (modelType == "off")
	{
		state = loadOFF(path, vertices);
	}
	if (modelType == "obj")
	{
		std::vector<glm::vec2> uvs;
		std::vector<glm::vec3> normals;
		state = loadOBJ(path, vertices, uvs, normals);
	}

	if (state)
	{
		/*glTranslatef(0, 0, 3);
		glRotatef(rotAngle, 0, 1, 0);
		glTranslatef(0, 0, -3);*/
		glBegin(GL_TRIANGLES);
		for (int i = 0; i < vertices.size(); i++)
		{
			glVertex3f(vertices[i].x, vertices[i].y, vertices[i].z);
		}
		glEnd();
	}

	// Flush OGL command
	glFinish();
}

void
upsidedownDepth(float *depth, int w, int h)
{
	float *buf;
	int    i;

	buf = (float *)(*ptrUTLMalloc)(sizeof(float)*w);

	if (!buf)
		cout << "upsidedownDepth : Not enough memory to allocate for buf!\n\n" << endl;

	for (i = 0; i<h / 2; i++) {
		memcpy(buf, depth + w*i, sizeof(float)*w);
		memcpy(depth + w*i, depth + w*(h - i - 1), sizeof(float)*w);
		memcpy(depth + w*(h - i - 1), buf, sizeof(float)*w);
	}

	(*ptrUTLFree)(buf);
}

////////////////////virtual scanner related functions///////////
float * 
holeGenerator(int regionSize, float regularization, int minRegionSize, int dropNum)
{
	/* get the depth value */
	float    *depth;
	int       w, h;

	GLint     viewport[4];
	glGetIntegerv(GL_VIEWPORT, viewport);

	w = viewport[2];
	h = viewport[3];

	depth = (GLfloat *)(*ptrUTLMalloc)(sizeof(GLfloat) * w * h);

	glPixelStorei(GL_PACK_ALIGNMENT, 1);
	glDepthRange(0.0, 1.0);
	glReadPixels(0, 0, w, h, GL_DEPTH_COMPONENT, GL_FLOAT, depth);

	// swap it upside down
	upsidedownDepth(depth, w, h);
	/* ------end---------- */
	
	/* superpixel */
	vl_size width = w;
	vl_size height = h;
	vl_size channels = 1;

	float* image = new float[width*height*channels];

	for (int i = 0; i<height; i++) {
		for (int j = 0; j<width; j++) {
			image[i*width + j] = depth[i*width + j];
		}
	}

	// The algorithm will store the final segmentation in a one-dimensional array.
	vl_uint32* segmentation = new vl_uint32[width*height];

	// The region size defines the number of superpixels obtained.
	// Regularization describes a trade-off between the color term and the
	// spatial term.
	vl_slic_segment(segmentation, image, width, height, channels, regionSize, regularization, minRegionSize);
	//cout<<segmentation[width*height-1]<<endl;
	/*---------END--------------*/

	/*random drop to create hole*/
	int maxValue = segmentation[width*height-1];
	dropNum = floor(maxValue/2);
	// generate random value
	srand(time(0));
	set<int> s;
	while(1)
	{
		int r = rand()%maxValue;
		s.insert(r);
		if(s.size()==dropNum)
		{
			break;
		}
	}

	set<int>::iterator it;
	for (int i = 0; i<height; i++) {
		for (int j = 0; j<width; j++) {
			for(it = s.begin(); it!=s.end(); ++it){
				if(segmentation[i*width + j]==*it && image[i*width + j]!=1)
				{
					image[i*width + j]=1;
				}
			}
		}
	}
	/*---------END---------*/

	//vl_free(image);
	return image;
}

void
Random_Probability(vector<int> &dropIndex, int deleteNum)
{
	if(deleteNum!=0)
	{
		int n = dropIndex.size();
		set<int> s;
		while(1)
		{
			int r = rand()%n;
			s.insert(r);
			if(s.size()==deleteNum)
			{
				break;
			}
		}
		set<int>::iterator it;
		for(it = s.begin(); it!=s.end(); ++it)
		{
			dropIndex[*it] = 1;
		}
	}
}

float * 
holeGenerator_new(int regionSize, float regularization, int minRegionSize, int dropNum)
{
	/* get the depth value */
	float    *depth;
	int       w, h;

	GLint     viewport[4];
	glGetIntegerv(GL_VIEWPORT, viewport);

	w = viewport[2];
	h = viewport[3];

	depth = (GLfloat *)(*ptrUTLMalloc)(sizeof(GLfloat) * w * h);

	glPixelStorei(GL_PACK_ALIGNMENT, 1);
	glDepthRange(0.0, 1.0);
	glReadPixels(0, 0, w, h, GL_DEPTH_COMPONENT, GL_FLOAT, depth);

	// swap it upside down
	upsidedownDepth(depth, w, h);
	/* ------end---------- */
	
	/* superpixel */
	vl_size width = w;
	vl_size height = h;
	vl_size channels = 1;

	float* image = new float[width*height*channels];

	for (int i = 0; i<height; i++) {
		for (int j = 0; j<width; j++) {
			image[i*width + j] = depth[i*width + j];
		}
	}

	// The algorithm will store the final segmentation in a one-dimensional array.
	vl_uint32* segmentation = new vl_uint32[width*height];

	// The region size defines the number of superpixels obtained.
	// Regularization describes a trade-off between the color term and the
	// spatial term.
	vl_slic_segment(segmentation, image, width, height, channels, regionSize, regularization, minRegionSize);
	//cout<<segmentation[0]<<endl;
	/*---------END--------------*/

	/*random drop to create hole*/
	int maxValue = segmentation[width*height-1];
	//cout<<maxValue<<endl;
	dropNum = floor(maxValue*0.0);
	//cout<<dropNum<<endl;
	// generate random value
	srand(time(0));
	set<int> s;
	if (dropNum!=0)
	{		
		while(1)
		{
			int r = rand()%maxValue;
			s.insert(r);
			if(s.size()==dropNum)
			{
				break;
			}
		}
	}	

	// generate random drop probability
	vector<float> p;
    for(int i = 0; i < dropNum; i ++)
		//p.push_back(rand()%(dropNum+1)/(float)(dropNum+1));
		p.push_back(0.0);

	//calculate the size of each superpixel region
	int segmentationNum = maxValue +1;
	vector<int> regionNum(segmentationNum, 0);
	for(int i = 0; i<height; i++){
		for(int j = 0; j<width; j++){
			regionNum[segmentation[i*width + j]]+=1;
		}
	}

	// random drop
	set<int>::iterator it;
	int idx = 0; // the index of drop region
	for(it = s.begin(); it!=s.end(); ++it)
	{
		//cout<<*it<<endl;
		int deletePixelNum = floor(regionNum[*it]*p[idx]);
		vector<int> dropIndex(regionNum[*it], 0);
		Random_Probability(dropIndex, deletePixelNum);
		int idxx = 0; // the index of drop pixel

		for (int i = 0; i<height; i++)
		{
			for(int j = 0; j<width; j++)
			{
				if(segmentation[i*width+j]==*it)
				{
					if(dropIndex[idxx]==1) {image[i*width+j] = 1;}
					idxx+=1;
					if(idxx==regionNum[*it]) {break;}
				}
			}
			if(idxx==regionNum[*it]) {break;}
		}

		idx+=1;
	}
	/*---------END---------*/

	//vl_free(image);
	return image;
}

vector<Point3D> 
generateNoNoisePL_Hole(float *image, const char* modelName, int viewIdx)
{
	vector<Point3D> output;

	int       i, w, h, x, y, zPos;
	GLdouble  realy;
	GLdouble  eyex, eyey, eyez;
	GLint     viewport[4];
	GLdouble  ident[16], projmatrix[16];

	glGetIntegerv(GL_VIEWPORT, viewport);
	glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);

	w = viewport[2];
	h = viewport[3];

	for (i = 0; i<16; i++)
		if (i % 5 == 0)
			ident[i] = 1.0;
		else
			ident[i] = 0.0;	

	zPos = 0;
	for (y = 0; y<h; y++)
		for (x = 0; x<w; x++) {
			realy = viewport[3] - (y + 0.5);

			if (gluUnProject((GLfloat)x + 0.5f, realy, image[zPos],
				ident, projmatrix, viewport,
				&eyex, &eyey, &eyez) == GL_FALSE)
				printf("False Return from gluUnProject!\n");

			/////////////generate point cloud from depth information
			if (image[zPos] != 1)
			{
				gluUnProject((GLfloat)x + 0.5f, realy, image[zPos],
					ident, projmatrix, viewport,
					&eyex, &eyey, &eyez);				
				Point3D point;
				point.x = eyex; point.y = eyey; point.z = eyez;
				output.push_back(point);			
			}
			zPos++;
		}
	return output;
}

float 
QuantizedNoiseGenerator(float input, int bins)
{
	float output = 0;
	float maxV = 1; float minV = 0;
	float step = (maxV - minV) / bins;
	for (int i = 0; i < bins; i++)
	{
		float lowerBound = minV + step*i;
		float upperBound = lowerBound + step;
		if (input >= lowerBound && input < (lowerBound+step/2))
		{
			output = lowerBound;
			break;
		}
		if (input >= (lowerBound + step / 2) && input <= upperBound)
		{
			output = upperBound;
			break;
		}
	}

	return output;
}

vector<Point3D> 
generateNoisePL_Hole(float *image, const char* modelName, int viewIdx, int noiseLevel)
{
	vector<Point3D> output;

	int       i, w, h, x, y, zPos;
	GLdouble  realy;
	GLdouble  eyex, eyey, eyez;
	GLint     viewport[4];
	GLdouble  ident[16], projmatrix[16];

	glGetIntegerv(GL_VIEWPORT, viewport);
	glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);

	w = viewport[2];
	h = viewport[3];

	for (i = 0; i<16; i++)
		if (i % 5 == 0)
			ident[i] = 1.0;
		else
			ident[i] = 0.0;

	zPos = 0;
	for (y = 0; y<h; y++)
	{
		for (x = 0; x<w; x++) 
		{
			realy = viewport[3] - (y + 0.5);
			
			if (gluUnProject((GLfloat)x + 0.5f, realy, image[zPos],
				ident, projmatrix, viewport,
				&eyex, &eyey, &eyez) == GL_FALSE)
				printf("False Return from gluUnProject!\n");

			/////////////generate point cloud from depth information
			if (image[zPos] != 1)
			{
				GLfloat depth_noise = 0;
				depth_noise = QuantizedNoiseGenerator(image[zPos], noiseLevel);
				//depth_hole[zPos] = GaussianGenerator(depth_hole[zPos], 0, 0.000001);
				if (depth_noise > 1)
				{
					depth_noise = 1;
					continue;
				}
			
				gluUnProject((GLfloat)x + 0.5f, realy, depth_noise,
					ident, projmatrix, viewport,
					&eyex, &eyey, &eyez);
				Point3D point;
				point.x = eyex; point.y = eyey; point.z = eyez;
				output.push_back(point);
			}

			zPos++;
		}
	}

	return output;
}


int
main(int argc, char** argv)
{
	HGLRC hRC;
	hRC = open_GL_RC(140, 140);  /////***********************point number
	myGLInit();

	/*char* path = argv[1];
	vector<string> v = split(path, "\\");
	string vv = v[7];
	vector<string> temp = split(vv, ".");
	string modelName = temp[0];
	v.clear();*/
	
	//char* path = "newtest_mesh\\5_repair.off";
	char* path = "table_1.off"; /////***********************input mesh
	string modelName = "table_1";
	////////////////////////////////////////////
	// parameters	
	int camNum = 1;   /////***********************camera number
	int noiseLevel = 200;//150;//100;  /////***********************noise level
	float rotAngle = 0;
	int regionSize = 10;
	int minRegionSize = 5;
	float regularizer = 0.01;
	int dropNum = 1300; //useless

	////////////////////////////////////////////
	myGLInit();
	vector<Point3D> no_noisePL;
	vector<Point3D> noisePL;
	vector<Point3D> noisePL_half;
	vector<Point3D> noisePL_double;
	for (int i = 1; i <= camNum; i++)
	{
		//rotAngle = 2*PI/camNum*(i-1)+(rand()%20-10)*(PI/180.0);
		rotAngle = (36*2)*(PI/180.0);
		initProj(rotAngle, i);
		display(path);
		/*float temp = rand() % (30)-15 + 360/camNum;
		rotAngle = rotAngle + temp;*/
		float *image;
		//image = holeGenerator(regionSize, regularizer, minRegionSize, dropNum);
		image = holeGenerator_new(regionSize, regularizer, minRegionSize, dropNum);

		////////////////create nonhomogeneous, noise-free output///////////
		vector<Point3D> no_noisePL_oneView;
		no_noisePL_oneView = generateNoNoisePL_Hole(image, modelName.c_str(), i);
		for (int j = 0; j < no_noisePL_oneView.size(); j++)
		{
			no_noisePL.push_back(no_noisePL_oneView[j]);
		}
		no_noisePL_oneView.clear();

		/////////////////create nonhomogeneous, noise output/////////////
		vector<Point3D> noisePL_oneView_double;
		noisePL_oneView_double = generateNoisePL_Hole(image, modelName.c_str(), i, noiseLevel/2);
		for (int j = 0; j < noisePL_oneView_double.size(); j++)
		{
			noisePL_double.push_back(noisePL_oneView_double[j]);
		}
		noisePL_oneView_double.clear();

		/////////////////create nonhomogeneous, noise output/////////////
		vector<Point3D> noisePL_oneView;
		noisePL_oneView = generateNoisePL_Hole(image, modelName.c_str(), i, noiseLevel);
		for (int j = 0; j < noisePL_oneView.size(); j++)
		{
			noisePL.push_back(noisePL_oneView[j]);
		}
		noisePL_oneView.clear();

		/////////////////create nonhomogeneous, noise output, half noise/////////////
		vector<Point3D> noisePL_oneView_half;
		noisePL_oneView_half = generateNoisePL_Hole(image, modelName.c_str(), i, noiseLevel*2);
		for (int j = 0; j < noisePL_oneView_half.size(); j++)
		{
			noisePL_half.push_back(noisePL_oneView_half[j]);
		}
		noisePL_oneView_half.clear();
	}

	/*FILE *fp_no_noise;
	char no_noisePath[50];
	sprintf(no_noisePath, "C:\\Users\\student\\Desktop\\Output_2\\%s_no_noise.xyz", modelName.c_str());
	fp_no_noise = fopen(no_noisePath, "w");
	for (int i = 0; i < no_noisePL.size(); i++)
	{
		fprintf(fp_no_noise, "%f %f %f\n", no_noisePL[i].x, no_noisePL[i].y, no_noisePL[i].z);
	}
	fclose(fp_no_noise);

	FILE *fp_noise;
	char noisePath[50];
	sprintf(noisePath, "C:\\Users\\student\\Desktop\\Output_2\\%s_noise.xyz", modelName.c_str());
	fp_noise = fopen(noisePath, "w");
	for (int i = 0; i < noisePL.size(); i++)
	{
		fprintf(fp_noise, "%f %f %f\n", noisePL[i].x, noisePL[i].y, noisePL[i].z);
	}
	fclose(fp_noise);*/

	FILE *fp_noise_half;
	char noisePath_half[50];
	sprintf(noisePath_half, "C:\\Users\\student\\Desktop\\Output_2\\%s_noise_half.xyz", modelName.c_str());
	fp_noise_half = fopen(noisePath_half, "w");
	for (int i = 0; i < noisePL_half.size(); i++)
	{
		fprintf(fp_noise_half, "%f %f %f\n", noisePL_half[i].x, noisePL_half[i].y, noisePL_half[i].z);
	}
	fclose(fp_noise_half);

	/*FILE *fp_noise_double;
	char noisePath_double[50];
	sprintf(noisePath_double, "C:\\Users\\student\\Desktop\\Output_2\\%s_noise_double.xyz", modelName.c_str());
	fp_noise_double = fopen(noisePath_double, "w");
	for (int i = 0; i < noisePL_double.size(); i++)
	{
		fprintf(fp_noise_double, "%f %f %f\n", noisePL_double[i].x, noisePL_double[i].y, noisePL_double[i].z);
	}
	fclose(fp_noise_double);*/

	//////////////////////////////////////////////
	// Close the rendering context
	close_GL_RC(hRC);

	//return (EXIT_SUCCESS);
	return 0;
}